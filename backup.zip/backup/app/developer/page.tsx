import { redirect } from 'next/navigation';

export default function DeveloperPage() {
  redirect('/developer/login');
}
