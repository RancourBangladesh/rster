import AdminPageWrapper from '@/components/AdminPageWrapper';
import EmployeeManagementTab from '@/components/AdminTabs/EmployeeManagementTab';
import { getSessionUser, getSessionUserData, getSessionTenantId } from '@/lib/auth';
import { loadAllForTenant } from '@/lib/dataStore';
import { redirect } from 'next/navigation';

export default function EmployeeManagementPage() {
  const user = getSessionUser();
  if (!user) redirect('/admin/login');
  
  const userData = getSessionUserData();
  const userRole = userData?.role || 'admin';
  
  const tenantId = getSessionTenantId();
  if (tenantId) {
    loadAllForTenant(tenantId);
  }

  return (
    <AdminPageWrapper adminUser={user} userRole={userRole}>
      <EmployeeManagementTab id="employee-management" />
    </AdminPageWrapper>
  );
}
